## UE901 EC3 Recommender System - Practical word

**Asmaa DEMNY & Fatima HABIB & Cécile MACAIRE & Chanoudom PRACH & Ludivine ROBERT**


## Context
This project has been realized under the _Recommender System_ course, as part of the _Natural Language Processing_ masters' degree in _Université de Lorraine (Nancy)_.

## Aim
Build a recommender system that receives a link from Wikipedia and recommends ten other links (based on existing works).

#### Required librairies

- gensim
- sickit-learn
